<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil CyberSkills</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

    <h1>Bienvenue sur CyberSkills</h1>

    <p>
        <a href="pages/identification.php" class="btn">Se connecter       </a>
        
        <a href="pages/inscription.php" class="btn">Créer un compte</a>
    </p>

</body>
</html>